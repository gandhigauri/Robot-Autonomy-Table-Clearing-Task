#!/usr/bin/env python

import openravepy
import numpy as np
import time
import os

if os.environ.get('ROS_DISTRO', 'hydro')[0] <= 'f':
    import roslib
    roslib.load_manifest('herbpy')

import argparse, herbpy, logging, numpy, openravepy, sys, prpy

#a= 2
#obj_list = [0,0,0]
'''
import os
if os.environ.get('ROS_DISTRO', 'hydro')[0] <= 'f':
    import roslib
    roslib.load_manifest('herbpy')


#if __name__ == "__main__":
parser = argparse.ArgumentParser(description='utility script for loading HerbPy')
parser.add_argument('-s', '--sim', action='store_true',
                        help='simulation mode')
parser.add_argument('-v', '--viewer', nargs='?', const=True,
                        help='attach a viewer of the specified type')
parser.add_argument('--robot-xml', type=str,
                        help='robot XML file; defaults to herb_description')
parser.add_argument('--env-xml', type=str,
                        help='environment XML file; defaults to an empty environment')
parser.add_argument('-b', '--segway-sim', action='store_true',
                        help='simulate base')
parser.add_argument('-p', '--perception-sim', action='store_true',
                        help='simulate perception')
parser.add_argument('--debug', action='store_true',
                        help='enable debug logging')
args = parser.parse_args()

openravepy.RaveInitialize(True)
openravepy.misc.InitOpenRAVELogging()

if args.debug:
        openravepy.RaveSetDebugLevel(openravepy.DebugLevel.Debug)

herbpy_args = {'sim':args.sim,
                   'attach_viewer':args.viewer,
                   'robot_xml':args.robot_xml,
                   'env_path':args.env_xml,
                   'segway_sim':args.segway_sim,
                   'perception_sim': args.perception_sim}
if args.sim and not args.segway_sim:
        herbpy_args['segway_sim'] = args.sim
'''    
env, robot = herbpy.initialize(sim=True, attach_viewer='rviz')
    
    #add a table
table = robot.GetEnv().ReadKinBodyXMLFile('models/data/furniture/table.kinbody.xml')
robot.GetEnv().Add(table)
table_pose = np.array([[ 0, 0, -1, 0.6], 
                           [-1, 0,  0, 0], 
                           [ 0, 1,  0, 0], 
                           [ 0, 0,  0, 1]])
table.SetTransform(table_pose)
    
    #add kinbodies
    #glass 1
target_kinbody1 = env.ReadKinBodyURI('models/data/objects/glass.kinbody.xml')
target_kinbody1.SetName("glass1")
robot.GetEnv().Add(target_kinbody1)
glass_pose = np.array([[ 0, 0, 0, 0.7], 
                           [-1, 0,  1, -0.5], 
                           [ 0, 1,  0, 0.7165], 
                           [ 0, 0,  0, 1]])
target_kinbody1.SetTransform(glass_pose)

    #glass 2
target_kinbody2 = env.ReadKinBodyURI('models/data/objects/glass.kinbody.xml')
target_kinbody2.SetName("glass2")
robot.GetEnv().Add(target_kinbody2)
glass_pose = np.array([[ 0, 0, 0, 0.5], 
                           [-1, 0,  1, -0.4], 
                           [ 0, 1,  0, 0.7165], 
                           [ 0, 0,  0, 1]])
target_kinbody2.SetTransform(glass_pose)

    #glass 3
target_kinbody3 = env.ReadKinBodyURI('models/data/objects/glass.kinbody.xml')
target_kinbody2.SetName("glass3")
robot.GetEnv().Add(target_kinbody3)
glass_pose = np.array([[ 0, 0, 0, 0.7], 
                           [-1, 0,  1, -0.3], 
                           [ 0, 1,  0, 0.7165], 
                           [ 0, 0,  0, 1]])
target_kinbody3.SetTransform(glass_pose)

    #add tray
target_tray = env.ReadKinBodyURI('models/data/objects/wicker_tray.kinbody.xml')
robot.GetEnv().Add(target_tray)
tray_pose = np.array([[ 0, 1, 0, 0.6], 
                          [1, 0,  0, 0.5], 
                          [ 0, 0,  1, 0.7165], 
                          [ 0, 0,  0, 1]])
target_tray.SetTransform(tray_pose)
obj_list=[target_kinbody1, target_kinbody2, target_kinbody3]
    
def bounding_box(body):
        obj  = body.ComputeAABB()
        max_xyz =  obj.pos()+obj.extents()
        min_xyz =  obj.pos()-obj.extents()
        min_max=np.hstack((min_xyz,max_xyz)).tolist()
        #print min_max
        return min_max
