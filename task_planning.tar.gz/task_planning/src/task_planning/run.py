#!/usr/bin/env python
import task_planning
import herbpy
#from HerbEnv import *
import HerbEnv
from Planner import *
import time


#robot.PlanToNamedConfiguration(home, execute = True)

def main():
	
	env, robot = herbpy.initialize(sim=True)
	obj_list = HerbEnv.obj_list
	#import IPython
	#IPython.embed()

	plan = Planner(env,obj_list)
	plan.Plan(obj_list)
	time.sleep(10000)


    #traj = robot.ConvertPlanToTrajectory(plan)
    #robot.ExecuteTrajectory(traj)    

if __name__ == "__main__":

	main()   
    
